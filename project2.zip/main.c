#include <stdio.h>
#include "items.h"
#include "rooms.h"

int main(void) {
  printf("Hello World\n");
  return 0;
}