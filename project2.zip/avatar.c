#include <stdio.h>
#include <stdlib.h> 
#include <string.h> 
#include "items.h"

typedef struct Avatar{
  char* name;
  Item *inventory;
  

};